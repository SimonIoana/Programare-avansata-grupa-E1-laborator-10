package ServerApplication;

import java.util.LinkedList;
import java.util.List;

public class Board {

    Square[][] squares;
    LinkedList<Piece> piece1;
    LinkedList<Piece> piece2;
    int currentPlayer;
    LinkedList<Move> moveHistory;
    LinkedList<Piece>[] pieces;
    int dimX;
    int dimY;


    public String Board(int dimX, int dimY, int firstPlayer) {

        this.dimX = dimX;
        this.dimY = dimY;
        currentPlayer = firstPlayer;
        squares = new Square[dimX][dimY];
        for (int i = 0; i < dimX; i++) {
            for (int j = 0; j < dimY; j++) {
                squares[i][j] = new Square(i, j);
            }
        }
        moveHistory = new LinkedList<Move>();
        piece1 = new LinkedList<Piece>();
        piece2 = new LinkedList<Piece>();
        pieces = (LinkedList<Piece>[])(new LinkedList[] {piece2,piece1});

        int shiftX,shiftY;
        for (int i = 0; i < dimX; i++) {
            for (int j = 0; j < dimY; j++) {
                for (int direction : Direction.DIRECTIONS) {
                    Square sq = squares[i][j];
                    shiftX = Direction.shiftX(sq.x, direction);
                    shiftY = Direction.shiftY(sq.y, direction);
                    if (shiftX >= 0 && shiftX < dimX && shiftY >= 0 && shiftY < dimY) {
                        sq.neighbors[direction] = squares[shiftX][shiftY];
                    }
                }
            }
        }
    }


    public int getCurrentPlayer() {
        return currentPlayer;
    }


    public List<Piece> getPieces(int side) {
        return pieces[side];
    }

    public Square getSquare(int x, int y) {
        return squares[x][y];
    }


    public void undoMove() {
        if (!moveHistory.isEmpty()) {
            Move lastMove = moveHistory.removeLast();
            // System.err.println("Undoing " + lastMove.player + "'s previous move.");
            squares[lastMove.x][lastMove.y].removePiece();
            pieces[lastMove.player].removeLast();
            currentPlayer = Player.other(currentPlayer);
        }
    }

    public boolean doMove(int x, int y) {
        return doMove(new Move(currentPlayer,x,y));
    }

    public int getDimX() {
        return dimX;
    }

    public int getDimY() {
        return dimY;
    }
    public int getPiece1() {
        return piece1;
    }
    public int getPiece2() {
        return piece2;
    }

    public boolean doMove(Move move) {
        boolean valid = isValid(move);
        if (valid) {
            pieces[move.player].add(squares[move.x][move.y].addPiece(move.player));
            moveHistory.add(move);
            currentPlayer = Player.other(currentPlayer);
        }
        return valid;
    }

    public boolean isValid(Move move) {
        return (move.player == currentPlayer &&
                move.x >= 0 && move.x < dimX &&
                move.y >= 0 && move.y < dimY &&
                squares[move.x][move.y].piece == null);
    }



}
